from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from .models import Student, Course
from .forms import EnrollmentForm

def enroll_student(request):
    if request.method == 'POST':
        form = EnrollmentForm(request.POST)
        if form.is_valid():
            student = form.save()
            return redirect(reverse_lazy('enrollment_confirmation'))
    else:
        form = EnrollmentForm()
    return render(request, 'enrollment/enroll.html', {'form': form})

def enrollment_confirmation(request):
    return render(request, 'enrollment/enrollment_confirmation.html')