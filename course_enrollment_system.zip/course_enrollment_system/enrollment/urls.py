from django.urls import path
from .views import enroll_student, enrollment_confirmation

urlpatterns = [
    path('enroll/', enroll_student, name='enroll'),
    path('confirmation/', enrollment_confirmation, name='enrollment_confirmation'),
]