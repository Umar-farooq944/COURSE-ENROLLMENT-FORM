from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('enrollment/', include('enrollment.urls')),
    path('', RedirectView.as_view(url='enrollment/enroll/')),  # Redirect root URL to enrollment form
]